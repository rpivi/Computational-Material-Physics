MODULE HSE_MODULE
  IMPLICIT NONE
  PRIVATE
  PUBLIC HSE_SOLVE, R, V

  ! NOTE: must be sufficiently low to find the ground state
  REAL(8) :: HSE_E_MIN = -20

  REAL(8), DIMENSION(:), ALLOCATABLE :: R  ! radial grid for solving the SE
  REAL(8), DIMENSION(:), ALLOCATABLE :: V  ! given potential on grid

CONTAINS
  ! Solves a hydrogen like Schroedinger equation in the given state with the
  ! main quantum number N and the angular quantum number L.
  ! The grid has to be specified in R and the potential is given in V
  ! on the same grid.
  ! The resulting radial part of the wave function is written in U=r*R(r).
  SUBROUTINE HSE_SOLVE(N, L, PREC, E, U)
    IMPLICIT NONE
    INTEGER, INTENT(IN) :: N                ! main quantum number
    INTEGER, INTENT(IN) :: L                ! angular quantum number
    REAL(8), INTENT(IN) :: PREC             ! desired energy precision
    REAL(8), INTENT(OUT) :: E               ! eigenvalue found
    REAL(8), DIMENSION(:), INTENT(OUT) :: U ! wave function on the grid

    REAL(8) :: E_MIN, E_MAX
    INTEGER :: I, NODES

    E_MIN = HSE_E_MIN
    E_MAX =  0

    DO WHILE (ABS(E_MAX-E_MIN) > PREC)
      E = (E_MIN+E_MAX)/2
      CALL HSE_INTEGRATE(L, E, U)

      ! count nodes
      NODES = 0
      DO I = 1, SIZE(R)-1
        IF (U(I)*U(I+1) < 0) NODES = NODES + 1
      END DO

      ! continue search in the above or below half
      IF (NODES > N-L-1) THEN
        E_MAX = E
      ELSE
        E_MIN = E
      ENDIF
    END DO

    CALL HSE_NORMALIZE(U)
  END SUBROUTINE

  SUBROUTINE HSE_INTEGRATE(L, E, U)
    IMPLICIT NONE
    INTEGER, INTENT(IN) :: L
    REAL(8), INTENT(IN) :: E
    REAL(8), DIMENSION(:), INTENT(OUT) :: U ! wave function on the grid
    INTEGER :: I, SAMPLES
    REAL(8) :: STEP

    SAMPLES = SIZE(R)
    ! NOTE: assumes regular grid
    STEP = (R(SAMPLES) - R(1)) / (SAMPLES-1)
    ! inward integration
    U(SAMPLES) = R(SAMPLES)*EXP(-R(SAMPLES))
    U(SAMPLES-1) = R(SAMPLES-1)*EXP(-R(SAMPLES-1))
    ! integrate inward using Verlet algorithm
    DO I = SAMPLES-1, 2, -1
      U(I-1) = 2*U(I) - U(I+1) + STEP**2*(-2*E + 2*V(I) + L*(L+1)/R(I)**2)*U(I)
    END DO
  END SUBROUTINE

  SUBROUTINE HSE_NORMALIZE(U)
    IMPLICIT NONE
    REAL(8), DIMENSION(:), INTENT(INOUT) :: U ! wave function to normalize
    REAL(8) :: NORM
    INTEGER :: I, SAMPLES
    REAL(8) :: STEP

    SAMPLES = SIZE(R)
    ! NOTE: assumes regular grid
    STEP = (R(SAMPLES) - R(1)) / (SAMPLES-1)
    NORM = (U(1)**2 + U(SAMPLES)**2) / 2
    DO I = 2, SAMPLES-1
      NORM = NORM + U(I)**2
    END DO
    U = U / SQRT(NORM * STEP)
  END SUBROUTINE

END MODULE
