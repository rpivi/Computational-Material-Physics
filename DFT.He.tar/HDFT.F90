MODULE HDFT_MODULE
  USE HSE_MODULE
  IMPLICIT NONE
  PRIVATE
  PUBLIC HDFT_SOLVE, NUCLEAR_CHARGE, N_ELECTRONS, U, RHO, V_H, V_X, V_C

  INTEGER :: NUCLEAR_CHARGE, N_ELECTRONS

  ! occupied orbitals U(r,n) = r*psi_n(r) where n is the orbital index
  REAL(8), DIMENSION(:,:), ALLOCATABLE :: U
  ! electron density normalized such that:
  ! int_0^infty rho^2(r) dr = n_electrons
  REAL(8), DIMENSION(:), ALLOCATABLE :: RHO

  ! Nuclear potential
  REAL(8), DIMENSION(:), ALLOCATABLE :: V_N
  ! Hartree potential
  REAL(8), DIMENSION(:), ALLOCATABLE :: V_H
  ! Exchange potential
  REAL(8), DIMENSION(:), ALLOCATABLE :: V_X
  ! Correlation potential
  REAL(8), DIMENSION(:), ALLOCATABLE :: V_C

  REAL(8), PARAMETER :: PI = ACOS(-1.0_8)

CONTAINS
  ! Solves a hydrogen like atom (s states only) with density functional theory
  ! on the grid defined in the HSE module.
  ! Note that N_ELECTRONS must be even as calculations is not spin-polarized.
  ! The total energy is returned.
  ! NUCLEAR_CHARGE, N_ELECTRONS and the grid of the HSE module must be
  ! initialized when calling.
  SUBROUTINE HDFT_SOLVE(PREC, TOTAL_ENERGY)
    IMPLICIT NONE
    REAL(8), INTENT(IN) :: PREC
    REAL(8), INTENT(OUT) :: TOTAL_ENERGY

    REAL(8) :: E, LAST_TOTAL_ENERGY

    CALL HDFT_INITIALIZE(SIZE(R))

    LAST_TOTAL_ENERGY = 1
    TOTAL_ENERGY = 0
    ! start self consistent loop with 0 density of the electrons
    RHO = 0
    DO WHILE (ABS(LAST_TOTAL_ENERGY - TOTAL_ENERGY) > PREC)
      LAST_TOTAL_ENERGY = TOTAL_ENERGY

      ! Get all contributions to the effective potential V
      CALL COMPUTE_NUCLEAR_POTENTIAL(R, V_N)
      CALL COMPUTE_HARTREE_POTENTIAL(R, RHO, V_H)
      CALL COMPUTE_EXCHANGE_POTENTIAL(R, RHO, V_X)
      CALL COMPUTE_CORRELATION_POTENTIAL(R, RHO, V_C)

      ! Uncomment the following three lines to get Hartree-Fock for He:
      !V_H = V_H/2
      !V_X = 0
      !V_C = 0
      ! compose the effective potential V
      V = V_N + V_H + V_X + V_C

      ! Solve Schroedinger equations for all occupied orbitals.
      ! The sum of all eigenvalues is returned in E.
      CALL COMPUTE_ORBITALS(E)
      ! Compute the density for the occupied orbitals
      CALL COMPUTE_DENSITY()

      ! compute the total energy:
      TOTAL_ENERGY = 2*E - POTENTIAL_ENERGY(V_H) &
        -POTENTIAL_ENERGY(V_X)/2 - POTENTIAL_ENERGY(V_C)/2
      !TOTAL_ENERGY = 2*E - POTENTIAL_ENERGY(V_H) 
      WRITE (0,*) TOTAL_ENERGY
    END DO
  END SUBROUTINE

  SUBROUTINE HDFT_INITIALIZE(SAMPLES)
    IMPLICIT NONE
    INTEGER, INTENT(IN) :: SAMPLES
    INTEGER :: N_ORBITALS
    N_ORBITALS = N_ELECTRONS / 2
    ALLOCATE(U(SAMPLES, N_ORBITALS))
    ALLOCATE(RHO(SAMPLES))
    ALLOCATE(V(SAMPLES))
    ALLOCATE(V_N(SAMPLES))
    ALLOCATE(V_H(SAMPLES))
    ALLOCATE(V_X(SAMPLES))
    ALLOCATE(V_C(SAMPLES))
  END SUBROUTINE

  ! Solve the hydrogen like Schroedinger equation for the potential V
  ! for all occupied orbitals and compute the resulting density rho
  SUBROUTINE COMPUTE_ORBITALS(E)
    IMPLICIT NONE
    REAL(8), INTENT(OUT) :: E  ! the sum of all eigenvalues eps_n
    INTEGER :: N
    REAL(8) :: E_N
    E = 0
    ! Go through all occupied states N, note that only s states are supported.
    DO N = 1, N_ELECTRONS/2
      CALL HSE_SOLVE(N, 0, 1D-9, E_N, U(:,N))
      E = E + E_N
    END DO
  END SUBROUTINE

  ! Compute the density for the occupied orbitals
  SUBROUTINE COMPUTE_DENSITY()
    IMPLICIT NONE
    INTEGER :: N
    RHO = 0
    DO N = 1, N_ELECTRONS/2
      ! every orbital is occipied with 2 electrons
      RHO = RHO + 2*U(:,N)**2
    END DO
  END SUBROUTINE

  ! Calculate the energy by integrating the given V(r)*rho(r)
  REAL(8) FUNCTION POTENTIAL_ENERGY(V_)
    REAL(8), DIMENSION(:), INTENT(IN) :: V_
    REAL(8) :: E, STEP
    INTEGER :: I, SAMPLES

    SAMPLES = SIZE(R)
    ! NOTE: assumes regular grid
    STEP = (R(SAMPLES) - R(1)) / (SAMPLES-1)

    E = 0
    DO I = 1, SAMPLES
      E = E + V_(I) * RHO(I)/2
    END DO
    POTENTIAL_ENERGY = E * STEP
  END FUNCTION

  ! Compute nuclear potential
  SUBROUTINE COMPUTE_NUCLEAR_POTENTIAL(R, V_N)
    IMPLICIT NONE
    REAL(8), DIMENSION(:), INTENT(IN) :: R
    REAL(8), DIMENSION(:), INTENT(OUT) :: V_N
    INTEGER :: I
    DO I = 1, SIZE(R)
      IF (R(I) > 0) THEN
        V_N(I) = -NUCLEAR_CHARGE / R(I)
      ELSE
        V_N(I) = 0
      END IF
    END DO
  END SUBROUTINE

  ! Compute Hartree potential from solving the Poisson equation
  ! U_H''(r) = -rho(r) / r
  ! with the boundary conditions U_H(0) = 0, U_H(r_max) = n_electrons.
  SUBROUTINE COMPUTE_HARTREE_POTENTIAL(R, RHO, V_H)
    IMPLICIT NONE
    REAL(8), DIMENSION(:), INTENT(IN) :: R, RHO
    REAL(8), DIMENSION(:), INTENT(OUT) :: V_H
    ! solution of the Poisson equation U_H''(r) = -rho(r)/r
    REAL(8), DIMENSION(SIZE(R)) :: U_H
    INTEGER :: I, SAMPLES
    REAL(8) :: ALPHA, STEP

    SAMPLES = SIZE(R)
    ! NOTE: assumes regular grid
    STEP = (R(SAMPLES) - R(1)) / (SAMPLES-1)

    ! First boundary condition: no charge within radius 0
    U_H(1) = 0
    ! alpha 0 assumed. r_max boundary condition matching done after integration
    U_H(2) = 0
    ! outwards integration using Verlet algorithm
    DO I = 2, SAMPLES-1, 1
      U_H(I+1) = 2*U_H(I) - U_H(I-1) - STEP**2 * RHO(I)/R(I)
    END DO

    ! match boundary condition at r_max:
    ! full charge of all electron within r_max
    ALPHA = (N_ELECTRONS - U_H(SAMPLES)) / R(SAMPLES)
    DO I = 1, SAMPLES
      U_H(I) = U_H(I) + ALPHA * R(I)
    END DO

    ! finally, get the Hartree potential from U_H
    DO I = 1, SIZE(R)
      IF (R(I) > 0) THEN
!        V_H(I) = U_H(I)/2 / R(I)
        V_H(I) = U_H(I) / R(I)
      ELSE
        V_H(I) = 0
      END IF
    END DO
  END SUBROUTINE

  ! Compute Exchange potential
  SUBROUTINE COMPUTE_EXCHANGE_POTENTIAL(R, RHO, V_X)
    IMPLICIT NONE
    REAL(8), DIMENSION(:), INTENT(IN) :: R, RHO
    REAL(8), DIMENSION(:), INTENT(OUT) :: V_X
    INTEGER :: I
    DO I = 1, SIZE(R)
      IF (R(I) > 0) THEN
        V_X(I) = -(3 * RHO(I) / (4*PI**2*R(I)**2)) ** (1.0_8/3)
      ELSE
        V_x(I) = 0
      END IF
    END DO
  END SUBROUTINE

  ! Compute the correlation potential according to Ceperly-Alder
  ! parameterization for the spin unpolarized system.
  SUBROUTINE COMPUTE_CORRELATION_POTENTIAL(R, RHO, V_C)
    IMPLICIT NONE
    REAL(8), DIMENSION(:), INTENT(IN) :: R, RHO
    REAL(8), DIMENSION(:), INTENT(OUT) :: V_C
    INTEGER :: I
    REAL(8) :: RS, E_C
    REAL(8), PARAMETER :: &
      A = 0.0311, B = -0.048, C = 0.002, D = -0.0116, &
      GAM = -0.1423, BETA1 = 1.0529, BETA2 = 0.3334

    DO I = 1, SIZE(R)
      IF (RHO(I) < 1E-10) THEN
        V_C(I) = 0
      ELSE
        RS = (3 * R(I)**2 / RHO(I)) ** (1.0_8/3)
        IF (RS < 1) THEN
          V_C(I) = A*LOG(RS) + B - A/3 + C*2/3*RS*LOG(RS) + (2*D-C)*RS/3
        ELSE IF (RS < 1E10) THEN
          E_C = GAM / (1 + BETA1*SQRT(RS) + BETA2*RS)
          V_C(I) = E_C * &
            (1+BETA1*7/6*SQRT(RS)+BETA2*4/3*RS) / (1+BETA1*SQRT(RS)+BETA2*RS)
        ELSE
          V_C(I) = 0
        END IF
      END IF
    END DO
  END SUBROUTINE
END MODULE

